<html>
<body>
<h2>EJB Application</h2>

<a href="ClientServlet">Get Book XML</a><br>

</body>
</html>