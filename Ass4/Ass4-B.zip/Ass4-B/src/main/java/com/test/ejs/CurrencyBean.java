/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package com.test.ejs;

import jakarta.ejb.Stateless;
import jakarta.ejb.LocalBean;

/**
 *
 * @author admin
 */
@Stateless
@LocalBean
public class CurrencyBean {

    public double convert(double amount) {
        double rate = 83.0; // dummy USD to INR
        return amount * rate;
    }

    public static void main(String[] args) {
        CurrencyBean c = new CurrencyBean();
        System.out.println(c.convert(10));
    }
}