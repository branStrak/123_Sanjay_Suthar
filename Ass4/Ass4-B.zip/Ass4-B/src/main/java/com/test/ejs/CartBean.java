/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package com.test.ejs;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */



public class CartBean {

    List<String> items = new ArrayList<>();

    public void addItem(String item) {
        items.add(item);
    }

    public void showItems() {
        for(String i : items) {
            System.out.println(i);
        }
    }
}