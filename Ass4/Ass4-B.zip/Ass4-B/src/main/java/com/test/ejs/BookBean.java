/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package com.test.ejs;

import jakarta.ejb.Stateless;
import jakarta.ejb.LocalBean;

/**
 *
 * @author admin
 */
@Stateless
@LocalBean
public class BookBean {

    public String getBookXML(int id) {

        String xml = "<book>";
        xml += "<id>" + id + "</id>";
        xml += "<name>Java Book</name>";
        xml += "<price>500</price>";
        xml += "</book>";

        return xml;
    }
}