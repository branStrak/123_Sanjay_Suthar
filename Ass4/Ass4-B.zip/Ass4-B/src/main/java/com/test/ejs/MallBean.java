/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB40/StatelessEjbClass.java to edit this template
 */
package com.test.ejs;

import jakarta.ejb.Stateless;
import jakarta.ejb.LocalBean;

/**
 *
 * @author admin
 */
@Stateless
@LocalBean
public class MallBean {

    public void addItem() {
        System.out.println("Item Added");
    }

    public void updateItem() {
        System.out.println("Item Updated");
    }

    public void deleteItem() {
        System.out.println("Item Deleted");
    }
}