/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.test.servlet;

import com.test.ejs.BookBean;
import java.io.IOException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author admin
 */
@WebServlet(name = "ClientServlet", urlPatterns = {"/ClientServlet"})
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import ejb.BookBean;

public class ClientServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        BookBean bb = new BookBean();
        String xml = bb.getBookXML(1);

        res.getWriter().println("Received XML: " + xml);
    }
}